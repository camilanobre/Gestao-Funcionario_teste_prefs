<template>
    <div>
<Titulo texto = "Sobre Nós" />
<p> Lorem ipsum dolor, sit amet consectetur adipisicing elit. Cupiditate repellat voluptatibus, explicabo voluptatem beatae ab blanditiis est sapiente dolores laudantium, praesentium sed architecto cumque quas sint nam quam molestiae a?</p>
    </div>

</template>

<script>
import Titulo from "../_share/Titulo";
export default {
  components: {
    Titulo
  }
}
</script>

<style scoped>

</style>