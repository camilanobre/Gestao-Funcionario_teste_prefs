
<template>
    <div>
        <Titulo texto="Sistema de Gestão de RH"/>
<p>Sejam bem vindos!!!</p>
<p>Com essa plataforma de interface simples, básica e fácil de utilizar, será possivel visualizar, alterar, adicionar
  ou excluir funcionários, bem como suas informações, do sistema.
</p>
    </div>
</template>

<script>
import Titulo from "../_share/Titulo";

export default {
  components: {
    Titulo
  },
}
</script>

<style scoped>

</style>